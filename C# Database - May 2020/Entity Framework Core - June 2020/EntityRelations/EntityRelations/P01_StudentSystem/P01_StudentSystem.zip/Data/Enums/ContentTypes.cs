﻿namespace P01_StudentSystem.Data.Enums
{
    public enum ContentTypes
    {
        Application,
        Pdf,
        Zip
    }
}
