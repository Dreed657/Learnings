﻿namespace P01_StudentSystem.Data.Enums
{
    public enum ResourceTypes
    {
        Video,
        Presentation,
        Decoument,
        Other
    }
}
