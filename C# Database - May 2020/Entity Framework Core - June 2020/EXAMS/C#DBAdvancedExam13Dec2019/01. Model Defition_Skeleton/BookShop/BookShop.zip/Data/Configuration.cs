﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=BookShop;Trusted_Connection=True";
    }
}