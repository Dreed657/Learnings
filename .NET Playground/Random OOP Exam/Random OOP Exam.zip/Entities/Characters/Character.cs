﻿using System;

using WarCroft.Constants;
using WarCroft.Entities.Inventory;
using WarCroft.Entities.Items;

namespace WarCroft.Entities.Characters.Contracts
{
    public abstract class Character
    {
        private string _name;
        private double _health;
        private double _armor;
        
        private double BaseHealth;
        private double BaseArmor;
        protected double AbilityPoints;
        private Bag Bag;

        protected Character(string name, double health, double armor, double abilityPoints, Bag bag)
        {
            this.Name = name;
            this.Health = health;
            this.Armor = armor;
            this.AbilityPoints = abilityPoints;
            this.Bag = bag;
        }

        public string Name
        {
            get => this._name;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(ExceptionMessages.CharacterNameInvalid);
                }

                this._name = value;
            }
        }

        public double Health
        {
            get => this._health;
            set
            {
                if (value > 0 && value < this.BaseHealth)
                {
                    this._health = value;
                }
            }
        }

        public double Armor
        {
            get => this._armor;
            set
            {
                if (value > 0)
                {
                    this._armor = value;
                }
            }
        }

		public bool IsAlive { get; set; } = true;

		protected void EnsureAlive()
		{
			if (!this.IsAlive)
			{
				throw new InvalidOperationException(ExceptionMessages.AffectedCharacterDead);
			}
		}

        public void TakeDamage(double hitPoints)
        {
            if (this.IsAlive)
            {
                if (this.Armor > 0)
                {
                    var armor = this.Armor;
                    var hitPointsLeft = hitPoints;
                    var armorLeft = armor - hitPointsLeft;

                    if (armorLeft < 0)
                    {
                        hitPointsLeft = Math.Abs(armorLeft);
                    }
                    else
                    {
                        this.Armor -= hitPointsLeft;
                    }

                    if (hitPointsLeft > 0)
                    {
                        this.Health -= hitPointsLeft;
                    }
                }

                if (this.Health < 0)
                {
                    this.IsAlive = false;
                }
            }
        }

        public void UseItem(Item item)
        {
            item.AffectCharacter(this);
        }
    }
}