﻿using System;

namespace WarCroft.Core
{
	public class WarController
	{
		public WarController()
		{
		}

		public string JoinParty(string[] args)
		{
			throw new NotImplementedException();
		}

		public string AddItemToPool(string[] args)
		{
			throw new NotImplementedException();
		}

		public string PickUpItem(string[] args)
		{
			throw new NotImplementedException();
		}

		public string UseItem(string[] args)
		{
			throw new NotImplementedException();
		}

		public string GetStats()
		{
			throw new NotImplementedException();
		}

		public string Attack(string[] args)
		{
			throw new NotImplementedException();
		}

		public string Heal(string[] args)
		{
			throw new NotImplementedException();
		}
	}
}
