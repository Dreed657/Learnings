﻿namespace BirthdayCelebrations.Contracts
{
    public interface IPet
    {
        string Name { get; set; }
    }
}
