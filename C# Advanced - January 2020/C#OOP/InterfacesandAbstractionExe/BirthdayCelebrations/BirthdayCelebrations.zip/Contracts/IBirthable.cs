﻿namespace BirthdayCelebrations.Contracts
{
    using System;

    public interface IBirthable
    {
        DateTime Birthdate { get; }
    }
}
