﻿namespace BirthdayCelebrations.Contracts
{
    public interface IRebel
    {
        int Age { get; set; }

        string Group { get; set; }
    }
}
