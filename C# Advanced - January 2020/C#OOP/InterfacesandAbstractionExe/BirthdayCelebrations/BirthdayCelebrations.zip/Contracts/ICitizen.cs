﻿namespace BirthdayCelebrations.Contracts
{
    public interface ICitizen
    {
        int Age { get; set; }
    }
}
