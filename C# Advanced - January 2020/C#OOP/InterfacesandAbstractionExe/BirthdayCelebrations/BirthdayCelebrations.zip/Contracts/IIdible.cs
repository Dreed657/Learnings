﻿namespace BirthdayCelebrations.Contracts
{
    public interface IIdible
    {
        string Id { get; set; }
    }
}
