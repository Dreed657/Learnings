﻿namespace BirthdayCelebrations.Contracts
{
    public interface IRobot
    {
        string Model { get; set; }
    }
}
