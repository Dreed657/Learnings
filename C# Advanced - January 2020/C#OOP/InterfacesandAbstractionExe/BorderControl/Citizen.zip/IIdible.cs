﻿namespace BorderControl
{
    public interface IIdible
    {
        string Id { get; set; }
    }
}
