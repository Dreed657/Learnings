﻿namespace BorderControl
{
    public interface IRobot
    {
        string Model { get; set; }
    }
}
