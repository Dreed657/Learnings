﻿namespace Stealer
{
    using System;
    using System.Reflection;
    using System.Linq;
    using System.Text;

    public class Spy
    {
        public string StealFieldInfo(string investigatedClass, params string[] requestedFields)
        {
            var classType = typeof(Hacker);
            FieldInfo[] classFields = classType.GetFields(BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public | BindingFlags.Static);

            var sb = new StringBuilder();

            var classInstance = Activator.CreateInstance(classType);

            sb.AppendLine($"Class under investigation: {investigatedClass}");

            foreach (FieldInfo item in classFields.Where(x => requestedFields.Contains(x.Name)))
            {
                sb.AppendLine($"{item.Name} = {item.GetValue(classInstance)}");
            }

            return sb.ToString().Trim();
        }
    }
}
