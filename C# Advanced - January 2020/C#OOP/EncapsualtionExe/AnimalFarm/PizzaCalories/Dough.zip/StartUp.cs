﻿namespace PizzaCalories
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var Engine = new Engine();
            Engine.Run();
        }
    }
}
