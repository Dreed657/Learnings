﻿namespace AquaShop.Core
{
    using System;
    using System.Linq;
    using System.Text;
    using System.Reflection;
    using System.Collections.Generic;

    using AquaShop.Core.Contracts;
    using AquaShop.Models.Fish.Models;
    using AquaShop.Models.Fish.Contracts;
    using AquaShop.Models.Aquariums.Models;
    using AquaShop.Models.Decorations.Models;
    using AquaShop.Repositories.Models;

    using Utilities.Messages;

    public class Controller : IController
    {
        private DecorationRepository Decorations;
        private ICollection<Aquarium> Aquariums;

        public Controller()
        {
            this.Decorations = new DecorationRepository();
            this.Aquariums = new List<Aquarium>();
        }

        public string AddAquarium(string aquariumType, string aquariumName)
        {
            var assembly = Assembly.GetCallingAssembly();
            var classType = assembly.GetTypes().FirstOrDefault(t => t.Name.ToLower() == aquariumType.ToLower());

            if (classType == null) return ExceptionMessages.InvalidAquariumType;

            Aquarium Aquarium;

            try
            {
                Aquarium = (Aquarium)Activator.CreateInstance(classType, aquariumName);
            }
            catch (TargetInvocationException ex)
            {
                return ex.InnerException.Message;
            }

            this.Aquariums.Add(Aquarium);

            return string.Format(OutputMessages.SuccessfullyAdded, aquariumType);
        }

        public string AddDecoration(string decorationType)
        {
            var assembly = Assembly.GetCallingAssembly();
            var classType = assembly.GetTypes().FirstOrDefault(t => t.Name.ToLower() == decorationType.ToLower());

            if (classType == null) return ExceptionMessages.InvalidDecorationType;

            var Decoration = (Decoration)Activator.CreateInstance(classType);

            this.Decorations.Add(Decoration);

            return string.Format(OutputMessages.SuccessfullyAdded, decorationType);
        }

        public string AddFish(string aquariumName, string fishType, string fishName, string fishSpecies, decimal price)
        {
            var assembly = Assembly.GetCallingAssembly();
            var classType = assembly.GetTypes().FirstOrDefault(t => t.Name.ToLower() == fishType.ToLower());

            if (classType == null) return ExceptionMessages.InvalidFishType;

            IFish Fish;

            try
            {
                Fish = (Fish)Activator.CreateInstance(classType, fishName, fishSpecies, price);
            }
            catch (TargetInvocationException ex)
            {
                return ex.InnerException.Message;
            }

            var aquarium = this.Aquariums.FirstOrDefault(x => x.Name == aquariumName);

            bool validFish = classType.Name.Replace("Fish", "") != aquarium.GetType().Name.Replace("Aquarium", "");
            if (validFish) return OutputMessages.UnsuitableWater;

            aquarium.AddFish(Fish);

            return string.Format(OutputMessages.EntityAddedToAquarium, classType.Name, aquariumName);
        }

        public string CalculateValue(string aquariumName)
        {
            Aquarium aquarium = this.Aquariums.FirstOrDefault(a => a.Name == aquariumName);
            Decimal sum = aquarium.Fish.Sum(x => x.Price) + aquarium.Decorations.Sum(x => x.Price);

            return string.Format(OutputMessages.AquariumValue, aquariumName, sum);
        }

        public string FeedFish(string aquariumName)
        {
            var aquarium = this.Aquariums.FirstOrDefault(a => a.Name == aquariumName);

            aquarium.Feed();

            return string.Format(OutputMessages.FishFed, aquarium.Fish.Count());
        }

        public string InsertDecoration(string aquariumName, string decorationType)
        {
            var decoration = this.Decorations.FindByType(decorationType);
            var aquarium = this.Aquariums.FirstOrDefault(x => x.Name == aquariumName);

            if (decoration == null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.InexistentDecoration, decorationType));
            }

            aquarium.AddDecoration(decoration);
            this.Decorations.Remove(decoration);

            return string.Format(OutputMessages.EntityAddedToAquarium, decorationType, aquariumName);
        }

        public string Report()
        {
            var sb = new StringBuilder();

            foreach (var aquarium in this.Aquariums)
            {
                sb.AppendLine(aquarium.GetInfo());
            }

            return sb.ToString().Trim();
        }
    }
}
