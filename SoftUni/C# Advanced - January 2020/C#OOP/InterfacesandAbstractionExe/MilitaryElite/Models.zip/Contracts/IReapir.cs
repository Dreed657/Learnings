﻿namespace MilitaryElite.Contracts
{
    public interface IRepair
    {
        string Part { get; }

        int Hours { get; }
    }
}
