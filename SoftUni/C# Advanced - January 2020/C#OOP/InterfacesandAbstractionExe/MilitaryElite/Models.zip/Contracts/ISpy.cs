﻿namespace MilitaryElite.Contracts
{
    public interface ISpy : ISoldier
    {
        int Code { get; }
    }
}
