﻿namespace MilitaryElite.Contracts
{
    public interface ISoldier
    {
        int Id { get; }

        string firstName { get; }

        string lastName { get; }
    }
}
