﻿namespace Polymorphism.Models
{
    public enum AirConditionerCondition
    {
        Off,
        On
    }
}
