﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IUsed
{
    int Used { get; }
}